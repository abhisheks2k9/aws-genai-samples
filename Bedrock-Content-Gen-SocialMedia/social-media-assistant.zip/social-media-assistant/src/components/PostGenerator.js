import { useState } from 'react';
import axios from 'axios';
import { BeakerIcon } from '@heroicons/react/24/solid';

const PostGenerator = () => {
  const [platform, setPlatform] = useState('Instagram');
  const [topic, setTopic] = useState('');
  const [result, setResult] = useState(null);

  const generatePost = async () => {
    try {
      const response = await axios.post(
        process.env.REACT_APP_API_URL,
        { platform, topic }
      );
      setResult(response.data);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto', padding: '20px' }}>
      <h1 style={{ fontSize: '24px', marginBottom: '20px' }}>
        <BeakerIcon style={{ width: '24px', height: '24px', marginRight: '8px' }} />
        Social Media Assistant
      </h1>

      <div style={{ marginBottom: '20px' }}>
        <select 
          value={platform}
          onChange={(e) => setPlatform(e.target.value)}
          style={{ width: '100%', padding: '8px', marginBottom: '10px' }}
        >
          <option>Instagram</option>
          <option>LinkedIn</option>
          <option>Twitter</option>
        </select>

        <input
          type="text"
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
          placeholder="Enter post topic"
          style={{ width: '100%', padding: '8px', marginBottom: '10px' }}
        />

        <button 
          onClick={generatePost}
          style={{
            width: '100%',
            padding: '10px',
            backgroundColor: '#2563eb',
            color: 'white',
            border: 'none',
            borderRadius: '4px'
          }}
        >
          Generate Post
        </button>
      </div>

      {result && (
        <div style={{ backgroundColor: '#f3f4f6', padding: '16px', borderRadius: '4px' }}>
          <h2 style={{ fontSize: '20px', marginBottom: '8px' }}>Caption:</h2>
          <p style={{ whiteSpace: 'pre-wrap' }}>{result.caption}</p>
          <h2 style={{ fontSize: '20px', marginBottom: '8px', marginTop: '16px' }}>Hashtags:</h2>
          <p style={{ color: '#2563eb' }}>{result.hashtags}</p>
        </div>
      )}
    </div>
  );
};

export default PostGenerator;
