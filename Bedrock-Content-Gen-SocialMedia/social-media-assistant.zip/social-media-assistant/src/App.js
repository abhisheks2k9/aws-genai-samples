import PostGenerator from './components/PostGenerator';

function App() {
  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#f3f4f6', padding: '20px' }}>
      <PostGenerator />
    </div>
  );
}

export default App;
